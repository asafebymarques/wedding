-- phpMyAdmin SQL Dump
-- version 4.4.15.7
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2019 at 12:07 AM
-- Server version: 5.6.37
-- PHP Version: 7.1.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fintechdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `categoria`
--

CREATE TABLE IF NOT EXISTS `categoria` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_alteracao` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `categoria`
--

INSERT INTO `categoria` (`id`, `descricao`, `status`, `data_criacao`, `data_alteracao`) VALUES
(6, 'Transporte', 1, '2019-06-05 11:23:25', '2019-06-05 14:27:11'),
(7, 'AlimentaÃ§Ã£o', 1, '2019-06-06 09:48:54', NULL),
(8, 'SalÃ¡rio', 1, '2019-06-06 09:49:01', NULL),
(9, 'Investimento', 1, '2019-06-06 09:49:08', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `financas`
--

CREATE TABLE IF NOT EXISTS `financas` (
  `id` int(11) NOT NULL,
  `tipoentradafk` tinyint(1) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `categoriafk` tinyint(3) NOT NULL,
  `data_debito` date NOT NULL,
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_alteracao` datetime DEFAULT NULL,
  `status` tinyint(4) DEFAULT '1',
  `valor` decimal(10,2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `financas`
--

INSERT INTO `financas` (`id`, `tipoentradafk`, `descricao`, `categoriafk`, `data_debito`, `data_criacao`, `data_alteracao`, `status`, `valor`) VALUES
(12, 3, 'Nextel', 9, '2019-06-25', '2019-06-06 10:01:54', '2019-06-06 19:49:33', 1, 200.00),
(13, 1, 'Salario', 8, '2019-06-06', '2019-06-06 10:08:22', NULL, 1, 8000.00);

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` int(10) unsigned NOT NULL,
  `hora` datetime NOT NULL,
  `ip` varchar(15) COLLATE latin1_general_ci NOT NULL,
  `relacionamento` varchar(200) COLLATE latin1_general_ci NOT NULL,
  `mensagem` text COLLATE latin1_general_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data for table `logs`
--

INSERT INTO `logs` (`id`, `hora`, `ip`, `relacionamento`, `mensagem`) VALUES
(2, '2019-06-06 21:01:39', '::1', 'FORM-LOGIN', 'Esse usuÃ¡rio ja existe!'),
(4, '2019-06-06 21:06:51', '::1', 'FORM-LOGIN', 'Esse usuÃ¡rio ja existe!');

-- --------------------------------------------------------

--
-- Table structure for table `tipoentrada`
--

CREATE TABLE IF NOT EXISTS `tipoentrada` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `data_criacao` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `data_alteracao` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tipoentrada`
--

INSERT INTO `tipoentrada` (`id`, `descricao`, `data_criacao`, `data_alteracao`, `status`) VALUES
(1, 'Receitas', '2019-06-05 14:52:26', '2019-06-05 14:52:35', 1),
(2, 'a', '2019-06-05 14:52:40', NULL, 0),
(3, 'Despesas', '2019-06-05 14:52:47', NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL,
  `data_nascimento` date DEFAULT NULL,
  `user` varchar(100) NOT NULL,
  `pass` varchar(100) NOT NULL,
  `data_criacao` datetime DEFAULT CURRENT_TIMESTAMP,
  `data_alteracao` datetime DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '1',
  `cpf` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

--
-- Dumping data for table `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `data_nascimento`, `user`, `pass`, `data_criacao`, `data_alteracao`, `status`, `cpf`) VALUES
(1, 'Asafe Brasil Yanez Marques', '1998-04-23', 'asafebymarques@icloud.com', '12322617857a!@A', '2019-06-04 09:49:40', '2019-06-05 11:18:59', 1, '483.635.878-77');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `financas`
--
ALTER TABLE `financas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tipoentradafk` (`tipoentradafk`),
  ADD KEY `categoriafk` (`categoriafk`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `hora` (`hora`);

--
-- Indexes for table `tipoentrada`
--
ALTER TABLE `tipoentrada`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `financas`
--
ALTER TABLE `financas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=14;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` int(10) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `tipoentrada`
--
ALTER TABLE `tipoentrada`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
